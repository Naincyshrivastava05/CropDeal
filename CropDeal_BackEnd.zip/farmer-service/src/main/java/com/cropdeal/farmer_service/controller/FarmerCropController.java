package com.cropdeal.farmer_service.controller;

import com.cropdeal.farmer_service.dto.CropDTO;
import com.cropdeal.farmer_service.feign.CropClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller to handle crop-related operations from the Farmer Service.
 * This uses a Feign client to communicate with the Crop Service.
 */
@RestController
@RequestMapping("/crop")
public class FarmerCropController {

    private final CropClient cropClient;

    // Constructor injection of the Feign client
    public FarmerCropController(CropClient cropClient) {
        this.cropClient = cropClient;
    }

    /**
     * Fetches all crops associated with a specific farmer.
     *
     * @param farmerId ID of the farmer whose crops need to be retrieved
     * @return List of CropDTO representing the farmer's crops
     */

    @GetMapping("/farmer/{farmerId}")
    public List<CropDTO> getCrops(@PathVariable Long farmerId) {
        return cropClient.getCropsByFarmerId(farmerId);
    }

    /**
     * Creates a new crop record by passing data to Crop Service.
     *
     * @param crop Crop data transfer object
     * @return Created CropDTO object
     */
    @PostMapping
    public CropDTO createCrop(@RequestBody CropDTO crop) {
        return cropClient.addCrop(crop);
    }

    /**
     * Updates a specific crop's details.
     *
     * @param id   Crop ID to be updated
     * @param crop Updated CropDTO object
     * @return Updated CropDTO
     */
    @PutMapping("/{id}")
    public CropDTO updateCrop(@PathVariable Long id, @RequestBody CropDTO crop) {
        return cropClient.updateCrop(id, crop);
    }

    /**
     * Deletes a crop by its ID using Crop Service.
     *
     * @param id Crop ID to be deleted
     */
    @DeleteMapping("/{id}")
    public void deleteCrop(@PathVariable Long id) {
        cropClient.deleteCrop(id);
    }
}