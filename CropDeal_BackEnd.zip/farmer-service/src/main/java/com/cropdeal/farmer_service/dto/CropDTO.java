package com.cropdeal.farmer_service.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CropDTO {
    private Long id;
    private String name;
    private String type;
    private Double quantity;
    private Double price;
    private String location;
    private String status;
    private Long farmerId;
}
