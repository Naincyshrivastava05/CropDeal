package com.cropdeal.farmer_service.feign;

import com.cropdeal.farmer_service.dto.CropDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Feign client interface for communicating with the Crop Service.
 * Uses dynamic URL configuration via 'crop.service.url' property.
 */
@FeignClient(name = "cropservice", url = "${crop.service.url}")
public interface CropClient {

    /**
     * Fetches all crops associated with a specific farmer ID.
     *
     * @param farmerId ID of the farmer
     * @return List of crops belonging to the farmer
     */
    @GetMapping("/farmer/{farmerId}")
    List<CropDTO> getCropsByFarmerId(@PathVariable Long farmerId);

    /**
     * Adds a new crop to the system.
     *
     * @param crop Crop data to be added
     * @return Created CropDTO object
     */
    @PostMapping
    CropDTO addCrop(@RequestBody CropDTO crop);

    /**
     * Retrieves all crops from the Crop Service.
     *
     * @return List of all available crops
     */
    @GetMapping
    List<CropDTO> getAllCrops();


    @GetMapping("/{id}")
    CropDTO getCropById(@PathVariable("id") Long id);

    /**
     * Updates crop information using the provided ID and new data.
     *
     * @param id   ID of the crop to update
     * @param crop Updated crop details
     * @return Updated CropDTO object
     */
    @PutMapping("/{id}")
    CropDTO updateCrop(@PathVariable("id") Long id, @RequestBody CropDTO crop);

    /**
     * Deducts the specified quantity from a crop’s available stock.
     *
     * @param id       Crop ID
     * @param quantity Amount to reduce
     * @return Status message indicating the result
     */
    @PutMapping("/{id}/reduce")
    String reduceCropQuantity(@PathVariable("id") Long id, @RequestParam("quantity") int quantity);

    /**
     * Deletes a crop by its ID.
     *
     * @param id ID of the crop to be deleted
     */
    @DeleteMapping("/{id}")
    void deleteCrop(@PathVariable("id") Long id);
}