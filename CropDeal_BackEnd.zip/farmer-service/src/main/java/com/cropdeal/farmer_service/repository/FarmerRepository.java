package com.cropdeal.farmer_service.repository;

import com.cropdeal.farmer_service.model.Farmer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * Repository interface for Farmer entity.
 * Extends JpaRepository to provide CRUD operations and custom queries.
 */
public interface FarmerRepository extends JpaRepository<Farmer, Long> {

    /**
     * Finds a farmer by their unique ID.
     *
     * @param id Farmer's ID
     * @return Optional containing Farmer if found
     */
    Optional<Farmer> findById(Long id);

    /**
     * Finds a farmer by their email address.
     * Used to check for duplicates during registration.
     *
     * @param email Farmer's email
     * @return Optional containing Farmer if found
     */
    Optional<Farmer> findByEmail(String email);

    /**
     * Finds a farmer by their username (name).
     * Useful for login or profile retrieval based on username.
     *
     * @param username Farmer's username
     * @return Optional containing Farmer if found
     */
    Optional<Farmer> findByName(String username);
}