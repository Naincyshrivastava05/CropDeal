package com.cropdeal.farmer_service.controller;

import com.cropdeal.farmer_service.dto.UserDTO;
import com.cropdeal.farmer_service.model.Farmer;
import com.cropdeal.farmer_service.service.FarmerService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/farmers")
public class FarmerController {

    private static final Logger logger = LoggerFactory.getLogger(FarmerController.class);

    @Autowired
    private FarmerService farmerService;

    /**
     * Endpoint to confirm service availability.
     */
    @GetMapping
    public String home() {
        logger.info("Accessed home endpoint");
        return "Welcome to Farmer Service";
    }

    /**
     * Registers a new farmer using user details.
     * The UserDTO is validated using Jakarta Bean Validation.
     */
    @PostMapping("/register")
    public ResponseEntity<?> createFarmer(@Valid @RequestBody UserDTO userDTO) {
        Farmer farmer = new Farmer();
        farmer.setName(userDTO.getUsername());
        farmer.setEmail(userDTO.getEmail());
        farmer.setPassword(userDTO.getPassword()); // Password is assumed to be encoded already
        farmer.setRole(userDTO.getRole());

        farmerService.addFarmer(farmer);
        return ResponseEntity.ok("Farmer registered");
    }

    /**
     * Retrieves farmer information using username.
     */
    @GetMapping("/{username}")
    public ResponseEntity<?> getUser(@PathVariable String username) {
        return ResponseEntity.ok(farmerService.findByUserName(username));
    }

    /**
     * Retrieves farmer information using their unique ID.
     */
    @GetMapping("/get/{id}")
    public ResponseEntity<?> getUser(@PathVariable Long id) {
        return ResponseEntity.ok(farmerService.getFarmerById(id));
    }

    /**
     * Updates an existing farmer's information using username as identifier.
     */
    @PutMapping("/{username}")
    public ResponseEntity<?> updateUser(@PathVariable String username, @RequestBody UserDTO updatedUser) {
        try {
            Optional<Farmer> optionalUser = farmerService.findByUserName(username);
            if (optionalUser.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
            }

            Farmer existingUser = optionalUser.get();
            // Update the farmer's details
            existingUser.setEmail(updatedUser.getEmail());
            existingUser.setPassword(updatedUser.getPassword()); // Presumed to be encoded
            existingUser.setRole(updatedUser.getRole());

            farmerService.addFarmer(existingUser);
            return ResponseEntity.ok("User updated successfully");
        } catch (Exception e) {
            logger.error("Error updating farmer", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to update user: " + e.getMessage());
        }
    }

    /**
     * RabbitMQ Listener for automatic farmer registration.
     * Triggered when AuthService sends registration data.
     */
    @RabbitListener(queues = "registration.farmer.queue")
    public void handleFarmerRegistration(UserDTO dto) {
        logger.info("Received farmer registration from AuthService for: {}", dto.getUsername());

        Optional<Farmer> existing = farmerService.findByUserId(String.valueOf(dto.getId()));
        if (existing.isEmpty()) {
            Farmer farmer = new Farmer();
            farmer.setName(dto.getUsername());
            farmer.setEmail(dto.getEmail());
            farmer.setId(dto.getId()); // Ensure UserDTO includes userId
            farmerService.addFarmer(farmer);

            logger.info("Farmer profile created for user ID: {}", dto.getId());
        } else {
            logger.warn("Farmer already exists for user ID: {}", dto.getId());
        }
    }
}