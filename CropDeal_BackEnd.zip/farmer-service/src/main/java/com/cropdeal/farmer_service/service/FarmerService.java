package com.cropdeal.farmer_service.service;

import com.cropdeal.farmer_service.dto.UserDTO;
import com.cropdeal.farmer_service.exception.DuplicateEmailException;
import com.cropdeal.farmer_service.model.Farmer;
import com.cropdeal.farmer_service.repository.FarmerRepository;
import jakarta.persistence.EntityNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Service layer for Farmer-related business logic and data operations.
 */
@Service
public class FarmerService {

    private static final Logger logger = LoggerFactory.getLogger(FarmerService.class);

    @Autowired
    private FarmerRepository repo;

    /**
     * Retrieves all farmers from the database.
     *
     * @return List of Farmer entities
     */
    public List<Farmer> getAllFarmers() {
        logger.info("Fetching all farmers from repository");
        return repo.findAll();
    }

    /**
     * Finds a farmer by username.
     *
     * @param username The name to search for
     * @return Optional containing Farmer if found
     */
    public Optional<Farmer> findByUserName(String username) {
        return repo.findByName(username);
    }

    /**
     * Gets a farmer by ID, throws exception if not found.
     *
     * @param id Farmer's unique identifier
     * @return Farmer entity
     */
    public Farmer getFarmerById(Long id) {
        logger.info("Fetching farmer by ID: {}", id);
        return repo.findById(id)
                .orElseThrow(() -> {
                    logger.warn("Farmer not found with ID: {}", id);
                    return new EntityNotFoundException("Farmer not found with id " + id);
                });
    }

    /**
     * Finds a farmer by user ID string (used in external integrations).
     *
     * @param userID String version of the user ID
     * @return Optional containing Farmer if found
     */
    public Optional<Farmer> findByUserId(String userID) {
        return repo.findById(Long.parseLong(userID));
    }

    /**
     * Adds a new farmer after checking for email duplication.
     *
     * @param farmer Farmer entity to persist
     * @return Saved Farmer entity
     */
    public Farmer addFarmer(Farmer farmer) {
        Optional<Farmer> existing = repo.findByEmail(farmer.getEmail());
        if (existing.isPresent()) {
            throw new DuplicateEmailException("Email already in use");
        }

        logger.info("Saving new farmer: {}", farmer.getName());
        Farmer saved = repo.save(farmer);
        logger.debug("Farmer saved: {}", saved);
        return saved;
    }

    /**
     * Deletes a farmer by ID.
     *
     * @param id ID of the farmer to delete
     */
    public void deleteFarmer(Long id) {
        logger.info("Deleting farmer with ID: {}", id);
        repo.deleteById(id);
        logger.info("Farmer with ID {} deleted successfully", id);
    }

    /**
     * Updates an existing farmer's data.
     *
     * @param id      ID of the farmer to update
     * @param updated Farmer entity with new data
     * @return Updated Farmer entity
     */
    public Farmer updateFarmer(Long id, Farmer updated) {
        logger.info("Updating farmer with ID: {}", id);
        updated.setId(id); // Ensure correct ID for update
        Farmer saved = repo.save(updated);
        logger.debug("Updated farmer: {}", saved);
        return saved;
    }

    /**
     * RabbitMQ listener for farmer registration events from AuthService.
     * Converts a UserDTO into a Farmer entity and persists it.
     *
     * @param dto Incoming user registration data
     */
    @RabbitListener(queues = "registration.farmer.queue")
    public void receiveFarmerRegistration(UserDTO dto) {
        Farmer farmer = new Farmer();
        farmer.setName(dto.getUsername());
        farmer.setEmail(dto.getEmail());
        // 🔄 Additional field mapping could be added here
        repo.save(farmer);
    }
}