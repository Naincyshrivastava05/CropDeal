package com.cropdeal.cropservice.service;

import com.cropdeal.cropservice.dto.FarmerDTO;
import com.cropdeal.cropservice.feign.FarmerClient;
import com.cropdeal.cropservice.model.Crop;
import com.cropdeal.cropservice.repository.CropRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CropServiceImpl implements CropService {

    private static final Logger logger = LoggerFactory.getLogger(CropServiceImpl.class);

    @Autowired
    private CropRepository repository;

    @Autowired
    private FarmerClient farmerClient;

    /**
     * Adds a crop after verifying that the farmer exists.
     * Throws an exception if the farmer ID is not valid.
     */
    @Override
    public Crop addCrop(Crop crop) {
        Long farmerId = crop.getFarmerId();
        logger.info("Attempting to add crop for farmer ID: {}", farmerId);

        ResponseEntity<FarmerDTO> response = farmerClient.getFarmerById(farmerId);
        FarmerDTO farmer = response.getBody();

        if (farmer == null) {
            logger.warn("Farmer not found with ID: {}", farmerId);
            throw new RuntimeException("Farmer not found with ID: " + farmerId);
        }

        Crop savedCrop = repository.save(crop);
        logger.debug("Crop saved: {}", savedCrop);
        return savedCrop;
    }

    /**
     * Retrieves and returns all crop records.
     */
    @Override
    public List<Crop> getAllCrops() {
        logger.info("Fetching all crops");
        return repository.findAll();
    }

    /**
     * Fetches a crop by its ID. Throws an exception if not found.
     */
    @Override
    public Crop getCropById(Long id) {
        logger.info("Fetching crop with ID: {}", id);
        return repository.findById(id).orElseThrow(() -> {
            logger.error("Crop not found with ID: {}", id);
            return new RuntimeException("Crop not found with ID: " + id);
        });
    }

    /**
     * Updates an existing crop using the provided ID and new crop details.
     */
    @Override
    public Crop updateCrop(Long id, Crop updatedCrop) {
        logger.info("Updating crop with ID: {}", id);
        Crop existing = repository.findById(id).orElseThrow(() -> {
            logger.error("Crop not found with ID: {}", id);
            return new RuntimeException("Crop not found with ID: " + id);
        });

        // Update fields
        existing.setName(updatedCrop.getName());
        existing.setType(updatedCrop.getType());
        existing.setPrice(updatedCrop.getPrice());
        existing.setQuantity(updatedCrop.getQuantity());

        Crop saved = repository.save(existing);
        logger.debug("Updated crop: {}", saved);
        return saved;
    }

    /**
     * Deletes a crop by its ID. Throws exception if the crop doesn't exist.
     */
    @Override
    public void deleteCrop(Long id) {
        logger.info("Deleting crop with ID: {}", id);
        if (!repository.existsById(id)) {
            logger.error("Crop not found with ID: {}", id);
            throw new RuntimeException("Crop not found with ID: " + id);
        }
        repository.deleteById(id);
        logger.info("Crop with ID {} deleted successfully", id);
    }

    /**
     * Finds all crops associated with a particular farmer ID.
     */
    @Override
    public List<Crop> findByFarmerId(Long farmerId) {
        System.out.println("reached service");
        List<Crop> list = repository.findByFarmerId(farmerId);
        System.out.println(list.size()); // Useful for debugging
        return repository.findByFarmerId(farmerId);
    }

    /**
     * Deducts a specified quantity from a crop’s stock.
     * If the stock reaches zero, marks crop as "Not Available".
     * Uses @Transactional to ensure changes are committed as one atomic operation.
     */
    @Override
    @Transactional
    public void deductQuantity(Long cropId, int amount) {
        Crop crop = repository.findById(cropId)
                .orElseThrow(() ->
                        new IllegalArgumentException("Crop not found: " + cropId)
                );

        double currentQty = crop.getQuantity();
        if (currentQty < amount) {
            throw new IllegalArgumentException(
                    "Insufficient stock for crop " + cropId
            );
        }

        System.out.println("Deducting " + amount + " units from crop " + cropId);
        crop.setQuantity(currentQty - amount);

        // If stock runs out, update status
        if (crop.getQuantity() == 0) {
            crop.setStatus("Not Available");
        }

        // Although @Transactional may auto-save, explicitly saving makes intentions clear
        repository.save(crop);
    }
}