package com.cropdeal.cropservice.feign;

import com.cropdeal.cropservice.dto.FarmerDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Feign client interface to communicate with the Farmer Service.
 */
@FeignClient(name = "farmer-service") // Specifies the name of the service to call
public interface FarmerClient {

    // Endpoint to fetch farmer details by ID from the Farmer Service
    @GetMapping("/api/farmers/get/{id}")
    ResponseEntity<FarmerDTO> getFarmerById(@PathVariable("id") Long id);
}
