package com.cropdeal.cropservice.service;

import com.cropdeal.payment_service.dto.PaymentMessage;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

/**
 * This component listens for payment success messages from RabbitMQ.
 * When a successful payment occurs, it deducts the purchased quantity from the crop inventory.
 */
@Component
public class PaymentMessageListener {

    // CropService is used to update crop quantity upon payment success
    private final CropService cropService;

    // Constructor injection for CropService
    public PaymentMessageListener(CropService cropService) {
        this.cropService = cropService;
    }

    /**
     * Listens to the RabbitMQ queue configured in application properties.
     * Triggered when a payment success message is received.
     * Deducts the quantity of the crop purchased.
     *
     * @param msg PaymentMessage containing cropId and quantity purchased
     */
    @RabbitListener(queues = "${rabbitmq.queue}")
    public void handlePaymentSuccess(PaymentMessage msg) {
        // Parse crop ID from message (assumed to be String format)
        Long cropId = Long.parseLong(msg.getCropId());

        // Extract quantity purchased from message
        int qty = msg.getQuantity();

        // Delegate to CropService to deduct stock
        cropService.deductQuantity(cropId, qty);
    }
}