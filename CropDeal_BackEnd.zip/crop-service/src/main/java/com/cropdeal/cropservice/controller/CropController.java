package com.cropdeal.cropservice.controller;

import com.cropdeal.cropservice.model.Crop;
import com.cropdeal.cropservice.service.CropService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for managing crop-related operations.
 */
@RestController
@RequestMapping("/crops")
public class CropController {

    private static final Logger logger = LoggerFactory.getLogger(CropController.class);

    @Autowired
    private CropService cropService; // Injecting CropService to handle business logic

    // Endpoint to add a new crop
    @PostMapping
    public ResponseEntity<Crop> addCrop(@RequestBody Crop crop) {
        logger.info("Received request to add crop: {}", crop);
        return ResponseEntity.ok(cropService.addCrop(crop));
    }

    // Endpoint to fetch all crops
    @GetMapping("/getAll")
    public ResponseEntity<List<Crop>> getAllCrops() {
        logger.info("Received request to fetch all crops");
        return ResponseEntity.ok(cropService.getAllCrops());
    }

    // Endpoint to fetch crops by farmer ID
    @GetMapping("/farmer/{farmerId}")
    public ResponseEntity<List<Crop>> getCropsByFarmerId(@PathVariable Long farmerId) {
        List<Crop> crops = cropService.findByFarmerId(farmerId);
        return ResponseEntity.ok(crops);
    }

    // Endpoint to fetch a crop by its ID
    @GetMapping("/{id}")
    public ResponseEntity<Crop> getCropById(@PathVariable Long id) {
        logger.info("Received request to fetch crop with ID: {}", id);
        return ResponseEntity.ok(cropService.getCropById(id));
    }

    // Endpoint to delete a crop by its ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCrop(@PathVariable Long id) {
        logger.info("Received request to delete crop with ID: {}", id);
        cropService.deleteCrop(id);
        return ResponseEntity.noContent().build(); // Return 204 No Content
    }

    // Endpoint to update a crop by its ID
    @PutMapping("/{id}")
    public Crop updateCrop(@PathVariable Long id, @RequestBody Crop crop) {
        logger.info("Received request to update crop with ID: {}", id);
        return cropService.updateCrop(id, crop);
    }

    // Endpoint to reduce crop quantity by a specified amount
    @PutMapping("/crops/{id}/reduce")
    public ResponseEntity<?> reduceCropQuantity(@PathVariable Long id, @RequestParam int quantity) {
        Crop crop = cropService.getCropById(id);

        if (crop == null) {
            return ResponseEntity.badRequest().body("Crop Not Found");
        }

        if (crop.getQuantity() < quantity) {
            return ResponseEntity.badRequest().body("Insufficient crop quantity");
        }

        // Reduce the crop quantity and update the crop
        crop.setQuantity(crop.getQuantity() - quantity);
        cropService.addCrop(crop);

        return ResponseEntity.ok("Quantity updated");
    }
}
