package com.cropdeal.cropservice.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.FanoutExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableRabbit

/**
 * Configuration class for RabbitMQ setup in the Crop Service.
 */

public class RabbitMQConfig {
    @Bean

// Declares a fanout exchange named "payment.exchange"

    public FanoutExchange paymentExchange() {
        return new FanoutExchange("payment.exchange");
    }

    @Bean
    public Queue cropQueue() {
        return new Queue("crop.payment.queue", true);
    }

// Binds the crop queue to the payment exchange

    @Bean
    public Binding binding(FanoutExchange paymentExchange, Queue cropQueue) {
        return BindingBuilder.bind(cropQueue).to(paymentExchange);
    }

    @Bean
    public MessageConverter jsonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }
}
