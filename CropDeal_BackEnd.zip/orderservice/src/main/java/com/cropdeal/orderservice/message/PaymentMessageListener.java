package com.cropdeal.orderservice.message;

import com.cropdeal.orderservice.service.OrderService;
import com.cropdeal.payment_service.dto.PaymentMessage;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

/**
 * Listener class for handling incoming payment messages via RabbitMQ.
 * Responsible for updating order status and payment status after transaction completion.
 */
@Component
public class PaymentMessageListener {

    private final OrderService orderService;

    // Constructor injection of OrderService for processing incoming payment updates
    public PaymentMessageListener(OrderService orderService) {
        this.orderService = orderService;
    }

    /**
     * RabbitMQ listener method triggered when a PaymentMessage is received.
     * The queue is configured via the application properties using '${rabbitmq.queue}'.
     *
     * @param message PaymentMessage containing orderId and payment status.
     */
    @RabbitListener(queues = "${rabbitmq.queue}")
    public void handlePaymentMessage(PaymentMessage message) {
        System.out.println("Received message: " + message);

        // Extract order ID and status from the incoming message
        String orderId = message.getOrderId();
        String status = message.getStatus();

        // Update the order's delivery/payment status
        orderService.updateStatus(Long.parseLong(orderId), status);

        // If the payment was successful, also update payment status to "Paid"
        if ("SUCCESS".equalsIgnoreCase(status)) {
            orderService.updatePaymentStatus(Long.parseLong(orderId), "Paid");
        }

        // Log confirmation to console for debugging or monitoring
        System.out.println("Order " + orderId + " updated payment status to Paid and Status to " + status);
        System.out.println("Received message: " + message); // Optional redundancy; can be removed if not needed
    }
}