package com.cropdeal.orderservice.controller;

import com.cropdeal.orderservice.entity.Order;
import com.cropdeal.orderservice.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * REST controller for managing orders.
 * Provides endpoints to place, retrieve, update, delete, and test orders.
 */
@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    /**
     * Places a new order.
     *
     * @param order Order details received from the request body
     * @return Persisted Order object
     */
    @PostMapping("/placeOrder")
    public Order createOrder(@RequestBody Order order) {
        return orderService.createOrder(order);
    }

    /**
     * Basic health check endpoint.
     * Confirms order service readiness.
     *
     * @return Status message
     */
    @GetMapping("/")
    public String getMessage() {
        return "Yes, you are ready to place order";
    }

    /**
     * Retrieves an order by its ID.
     *
     * @param id Order ID
     * @return Optional Order object if found
     */
    @GetMapping("/{id}")
    public Optional<Order> getOrderById(@PathVariable Long id) {
        return orderService.getOrderById(id);
    }

    /**
     * Fetches all orders placed by a specific farmer.
     *
     * @param id Farmer ID
     * @return List of orders for the farmer
     */
    @GetMapping("/farmer/{id}")
    public ResponseEntity<List<Order>> getOrderByFarmerId(@PathVariable Long id) {
        return new ResponseEntity<>(orderService.getOrderByFarmerId(id), HttpStatus.OK);
    }

    @GetMapping("/dealers/{id}")
    public ResponseEntity<List<Order>> getOrderByDealerId(@PathVariable Long id) {
        return new ResponseEntity<>(orderService.getOrderByDealerId(id), HttpStatus.OK);
    }

    /**
     * Updates an existing order based on its ID.
     *
     * @param id    Order ID
     * @param order Updated order details
     * @return Updated Order object
     */
    @PutMapping("/{id}")
    public Order updateOrder(@PathVariable Long id, @RequestBody Order order) {
        return orderService.updateOrder(id, order);
    }

    /**
     * Deletes an order using its ID.
     *
     * @param id Order ID to delete
     */
    @DeleteMapping("/{id}")
    public void deleteOrder(@PathVariable Long id) {
        orderService.deleteOrder(id);
    }

    /**
     * Test endpoint for verifying Feign clients and service integration.
     * Retrieves farmer, dealer, and crop information using external services.
     *
     * @param farmerId ID of the farmer
     * @param dealerId ID of the dealer
     * @param cropId   ID of the crop
     * @return Map containing related data from other services
     */
    @GetMapping("/test/{farmerId}/{dealerId}/{cropId}")
    public Map<String, Object> testFeignClients(
            @PathVariable String farmerId,
            @PathVariable String dealerId,
            @PathVariable String cropId) {

        Map<String, Object> response = new HashMap<>();
        response.put("farmer", orderService.getFarmerById(farmerId));
        response.put("dealer", orderService.getDealerById(dealerId));
        response.put("crop", orderService.getCropById(cropId));

        return response;
    }

}