package com.cropdeal.orderservice.dto;


public class FarmerDTO {
    private String id;


    public FarmerDTO() {
    }

    public FarmerDTO(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

}
