package com.cropdeal.orderservice.service;

import com.cropdeal.orderservice.dto.CropDTO;
import com.cropdeal.orderservice.dto.DealerDTO;
import com.cropdeal.orderservice.dto.FarmerDTO;
import com.cropdeal.orderservice.entity.Order;
import com.cropdeal.orderservice.feign.CropClient;
import com.cropdeal.orderservice.feign.DealerClient;
import com.cropdeal.orderservice.feign.FarmerClient;
import com.cropdeal.orderservice.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Service layer for handling order-related business logic.
 * Interacts with Crop, Farmer, and Dealer microservices via Feign clients.
 */
@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CropClient cropClient;

    @Autowired
    private FarmerClient farmerClient;

    @Autowired
    private DealerClient dealerClient;

    /**
     * Updates the order's delivery status.
     *
     * @param orderId Order ID to update
     * @param status  New status string
     * @return Updated Order entity
     */
    public Order updateStatus(Long orderId, String status) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + orderId));

        order.setStatus(status);
        System.out.println("Updating order " + orderId + " to status " + status);
        return orderRepository.save(order);
    }

    /**
     * Updates the payment status of an order.
     *
     * @param orderId       Order ID
     * @param paymentStatus New payment status string
     */
    public void updatePaymentStatus(Long orderId, String paymentStatus) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + orderId));

        order.setPaymentStatus(paymentStatus);
        System.out.println("Updating order " + orderId + " to paymentStatus " + paymentStatus);
        orderRepository.save(order);
    }

    /**
     * Retrieves farmer information via Feign client.
     */
    public FarmerDTO getFarmerById(String id) {
        return farmerClient.getFarmerById(id);
    }

    /**
     * Retrieves dealer information via Feign client.
     */
    public DealerDTO getDealerById(String id) {
        return dealerClient.getDealerById(id);
    }

    /**
     * Retrieves crop information via Feign client.
     */
    public CropDTO getCropById(String id) {
        return cropClient.getCropById(id);
    }

    /**
     * Retrieves all orders associated with a specific farmer ID.
     */
    public List<Order> getOrderByFarmerId(Long id) {
        return orderRepository.findByFarmerId(id.toString());
    }

    public List<Order> getOrderByDealerId(Long id) {
        return orderRepository.findByDealerId(id.toString());
    }

    /**
     * Creates a new order after validating crop availability and enriching it with related data.
     *
     * @param order Order entity to be saved
     * @return Persisted Order entity
     */
    public Order createOrder(Order order) {
        CropDTO crop = cropClient.getCropById(order.getCropId());
        FarmerDTO farmer = farmerClient.getFarmerById(order.getFarmerId());
        DealerDTO dealer = dealerClient.getDealerById(order.getDealerId());

        if (crop == null) {
            throw new RuntimeException("Invalid crop ID: " + order.getCropId());
        }

        // Validate quantity
        if (crop.getQuantity() < order.getQuantity()) {
            throw new RuntimeException("Requested quantity exceeds available stock");
        }

        // Enrich order with validated and fetched details
        order.setCropName(crop.getName());
        order.setCropType(crop.getType());
        order.setFarmerId(farmer.getId());
        order.setDealerId(dealer.getId());
        order.setStatus("Pending");

        // Placeholder for publishing event via RabbitMQ
        // String msg = "Dealer " + order.getDealerId() + " ordered Crop ID:" + order.getCropId() + "\n Crop Name:" + order.getCropName();
        // rabbitTemplate.convertAndSend("cropdeal-exchange", "order placed", msg);

        return orderRepository.save(order);
    }

    /**
     * Retrieves all orders from the database.
     */
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    /**
     * Retrieves a single order by its ID.
     */
    public Optional<Order> getOrderById(Long id) {
        return orderRepository.findById(id);
    }

    /**
     * Updates an existing order with new data, or creates one if not found.
     *
     * @param id           Order ID
     * @param updatedOrder Order entity with updated fields
     * @return Saved Order entity
     */
    public Order updateOrder(Long id, Order updatedOrder) {
        return orderRepository.findById(id).map(order -> {
            order.setCropId(updatedOrder.getCropId());
            order.setCropName(updatedOrder.getCropName());
            order.setCropType(updatedOrder.getCropType());
            order.setFarmerId(updatedOrder.getFarmerId());
            order.setDealerId(updatedOrder.getDealerId());
            order.setPrice(updatedOrder.getPrice());
            order.setQuantity(updatedOrder.getQuantity());
            order.setStatus(updatedOrder.getStatus());
            order.setOrderDate(updatedOrder.getOrderDate());
            order.setPaymentStatus(updatedOrder.getPaymentStatus());
            return orderRepository.save(order);
        }).orElseGet(() -> {
            updatedOrder.setOrderId(id);
            return orderRepository.save(updatedOrder);
        });
    }

    /**
     * Deletes an order using its ID.
     */
    public void deleteOrder(Long id) {
        orderRepository.deleteById(id);
    }
}