package com.cropdeal.orderservice.config;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * RabbitMQ configuration for Order Service.
 * Sets up exchange, queues, bindings, and necessary components for message publishing and consumption.
 */
@Configuration
public class RabbitMQConfig {

    // Inject values from application properties
    @Value("${rabbitmq.exchange}")
    private String exchange;

    @Value("${rabbitmq.queue}")
    private String queue;

    @Value("${rabbitmq.routingkey}")
    private String routingKey;

    /**
     * Declares the topic exchange to enable routing based on pattern matching.
     */
    @Bean
    public TopicExchange topicExchange() {
        return new TopicExchange(exchange);
    }

    /**
     * Declares the main queue used by the order service.
     */
    @Bean
    public Queue queue() {
        return new Queue(queue);
    }

    /**
     * Binds the declared queue to the exchange using a routing key.
     * Ensures messages with matching keys reach the correct queue.
     */
    @Bean
    public Binding binding(Queue queue, TopicExchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with(routingKey);
    }

    /**
     * Declares a separate queue for handling payment success events.
     * Set to durable to persist messages even if RabbitMQ restarts.
     */
    @Bean
    public Queue paymentSuccessQueue() {
        return new Queue("payment.success.queue", true);
    }

    /**
     * Configures the message converter to use JSON for message serialization and deserialization.
     */
    @Bean
    public Jackson2JsonMessageConverter messageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    /**
     * Configures RabbitTemplate with the JSON message converter for sending messages.
     */
    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
        RabbitTemplate template = new RabbitTemplate(connectionFactory);
        template.setMessageConverter(messageConverter());
        return template;
    }

    /**
     * Sets up listener container factory to use JSON message converter for consuming messages.
     */
    @Bean
    public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(ConnectionFactory connectionFactory) {
        SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
        factory.setConnectionFactory(connectionFactory);
        factory.setMessageConverter(messageConverter());
        return factory;
    }

    /**
     * Admin bean to programmatically declare queues, exchanges, and bindings at runtime.
     * Ensures configuration is auto-applied on startup.
     */
    @Bean
    public AmqpAdmin rabbitAdmin(ConnectionFactory cf) {
        RabbitAdmin admin = new RabbitAdmin(cf);
        admin.setAutoStartup(true);
        return admin;
    }
}