package com.cropdeal.orderservice.dto;

public class DealerDTO {
    private String id;

    public DealerDTO() {}

    public DealerDTO(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
