package com.cropdeal.notification_service.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

// Configuration class for setting up RabbitMQ components
@Configuration
public class RabbitMQConfig {

    // Injects queue name from application properties
    @Value("${rabbitmq.queue}")
    private String queue;

    // Injects exchange name from application properties
    @Value("${rabbitmq.exchange}")
    private String exchange;

    // Injects routing key from application properties
    @Value("${rabbitmq.routingkey}")
    private String routingKey;

    /**
     * Declares a RabbitMQ Queue.
     * This queue will receive messages using the defined routing key.
     */
    @Bean
    public Queue queue() {
        return new Queue(queue);
    }

    /**
     * Declares a TopicExchange for publishing events.
     * TopicExchange routes messages to queues based on routing patterns.
     */
    @Bean
    public TopicExchange exchange() {
        return new TopicExchange(exchange);
    }

    /**
     * Binds the declared queue to the exchange using the provided routing key.
     * This ensures that messages published with the matching key will be delivered to the queue.
     */
    @Bean
    public Binding binding(Queue queue, TopicExchange exchange) {
        return BindingBuilder
                .bind(queue)
                .to(exchange)
                .with(routingKey);
    }
}