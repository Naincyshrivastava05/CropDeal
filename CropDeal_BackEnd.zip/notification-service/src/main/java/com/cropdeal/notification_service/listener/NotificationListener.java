package com.cropdeal.notification_service.listener;

import com.cropdeal.notification_service.model.CropPublishedEvent;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

/**
 * Listener service that responds to crop publication events sent via RabbitMQ.
 * Intended to notify dealers or external systems when a new crop is made available.
 */
@Service
public class NotificationListener {

    /**
     * RabbitMQ listener method triggered when a CropPublishedEvent is received.
     * The queue name is injected from application properties via '${rabbitmq.queue}'.
     *
     * @param event CropPublishedEvent containing crop type, location, and farmer ID
     */
    @RabbitListener(queues = "${rabbitmq.queue}")
    public void handleCropPublished(CropPublishedEvent event) {
        // Logs crop publication to the console (can later be replaced with proper notification logic)
        System.out.println("📢 New crop published: " + event.getCropType() +
                " at " + event.getLocation() + " by Farmer " + event.getFarmerId());

        // TODO: Integrate with dealer notification system (e.g., email, SMS, mobile push)
        // You can use services like Twilio, Firebase, or Spring Mail here.
    }
}