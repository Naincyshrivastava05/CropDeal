package com.cropdeal.notification_service.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * POJO representing a crop publication event.
 * This object is used as a message payload when a crop is published.
 * Typically passed through RabbitMQ to notify consumers like dealers.
 */
@AllArgsConstructor         // Lombok: Generates constructor with all fields
@NoArgsConstructor          // Lombok: Generates no-arg constructor
@Getter                     // Lombok: Generates getters for all fields
@Setter                     // Lombok: Generates setters for all fields
public class CropPublishedEvent {

    private String cropId;      // Unique ID of the published crop
    private String cropType;    // Type or category of the crop (e.g., wheat, rice)
    private String farmerId;    // ID of the farmer who published the crop
    private String location;    // Location where the crop is available
    private int quantity;       // Quantity available for sale

    // Lombok eliminates the need to manually write getters/setters
}