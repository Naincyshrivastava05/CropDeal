package com.cropdeal.notification_service.controller;

import com.cropdeal.notification_service.model.CropPublishedEvent;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

/**
 * Controller used to manually test publishing events to RabbitMQ.
 * This is typically used for internal testing or triggering messages manually.
 */
@RestController
@RequestMapping("/test")  // Base endpoint for testing publication
public class TestPublisherController {

    @Autowired
    private RabbitTemplate rabbitTemplate;  // Used to send messages to RabbitMQ

    @Value("${rabbitmq.exchange}")         // Injects exchange name from config
    private String exchange;

    @Value("${rabbitmq.routingkey}")       // Injects routing key from config
    private String routingKey;

    /**
     * Publishes a CropPublishedEvent to RabbitMQ using the configured exchange and routing key.
     *
     * @param event Event payload received from the request body
     * @return Status message confirming publication
     */
    @PostMapping("/publish")
    public String publishEvent(@RequestBody CropPublishedEvent event) {
        rabbitTemplate.convertAndSend(exchange, routingKey, event);
        return "Event published!";
    }
}