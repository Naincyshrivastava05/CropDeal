package com.admin.service;

import com.admin.dto.AdminDTO;
import com.admin.exception.InvalidAdminException;
import com.admin.model.Admin;
import com.admin.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * Service class for handling Admin-related business logic.
 */
@Service
public class AdminService {

    // Injecting AdminRepository to interact with the database
    @Autowired
    private AdminRepository adminRepository;

    // Finds an Admin by ID or throws an exception if not found
    public Admin findById(int id) throws InvalidAdminException {
        return adminRepository.findById(id)
                .orElseThrow(() -> new InvalidAdminException("Invalid Id"));
    }

    // Adds a new Admin using data from AdminDTO
    public Admin addAdmin(AdminDTO s) {
        Admin a = new Admin();
        a.setName(s.getName());           // Set name from DTO
        a.setPassword(s.getPassword());   // Set password from DTO
        a.setUserName(s.getUserName());   // Set username from DTO
        a.setEmail(s.getEmail());         // Set email from DTO
        return adminRepository.save(a);   // Save admin to database
    }

    // Deletes an Admin by ID and returns null (can be improved to return status)
    public Admin deleteById(int id) {
        if (!adminRepository.existsById(id)) {
            throw new InvalidAdminException("Invalid Id"); // Throw if ID doesn't exist
        }
        adminRepository.deleteById(id); // Delete admin by ID
        return null; // Optional: return deleted admin or confirmation
    }

    // Authenticates an Admin by username
    public Admin authAdmin(String userName) throws InvalidAdminException {
        Optional<Admin> admin = adminRepository.findByUserName(userName);
        if (admin.isPresent()) {
            return admin.get(); // Return admin if found
        } else {
            throw new InvalidAdminException("No admin found"); // Throw if not found
        }
    }
}
