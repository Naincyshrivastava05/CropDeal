package com.admin.controller;

import com.admin.feign.DealerFeign;
import com.admin.model.Dealer;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller for handling Admin-side operations related to Dealers.
 */
@RestController
@RequestMapping("/admin")
public class DealerController {

    // Injecting Feign client to communicate with Dealer service
    @Autowired
    DealerFeign dealerFeign;

    // Endpoint to fetch all dealers
    @GetMapping("/getAll/dealer")
    public ResponseEntity<List<Dealer>> getAll() {
        return dealerFeign.getAll(); // Delegates call to Dealer service via Feign
    }

    // Endpoint to fetch a dealer by ID
    @GetMapping("/viewDealerById/{dealerId}")
    public ResponseEntity<Dealer> viewDealerById(@Valid @PathVariable int dealerId) {
        return dealerFeign.getById(dealerId); // Delegates call to Dealer service via Feign
    }

    // Endpoint to delete a dealer by ID
    @DeleteMapping("/deleteFarmer/{dealerId}")
    public ResponseEntity<Dealer> deleteDealer(@Valid @PathVariable int dealerId) {
        return dealerFeign.deleteById(dealerId); // Delegates call to Dealer service via Feign
    }
}
