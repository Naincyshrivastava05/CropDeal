package com.admin.controller;

import com.admin.feign.FarmerFeign;
import com.admin.model.Farmer;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller for handling Admin-side operations related to Farmers.
 */
@RestController
@RequestMapping("/admin")
public class FarmerController {

    // Injecting Feign client to communicate with Farmer service
    @Autowired
    FarmerFeign farmerFeign;

    // Endpoint to fetch all farmers
    @GetMapping("/getAll/farmer")
    public ResponseEntity<List<Farmer>> getAll() {
        return farmerFeign.getAll(); // Delegates call to Farmer service via Feign
    }

    // Endpoint to fetch a farmer by ID
    @GetMapping("/viewFarmerById/{farmerId}")
    public ResponseEntity<Farmer> viewFarmerById(@PathVariable int farmerId) {
        return farmerFeign.getById(farmerId); // Delegates call to Farmer service via Feign
    }

    // Endpoint to delete a farmer by ID
    @DeleteMapping("/deleteFarmer/{farmerId}")
    public ResponseEntity<Farmer> deleteStudent(@Valid @PathVariable int farmerId) {
        return farmerFeign.deleteById(farmerId); // Delegates call to Farmer service via Feign
    }
}
