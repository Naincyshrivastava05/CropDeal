package com.admin.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object for Admin entity.
 */
@Data // Lombok annotation to generate getters, setters, toString, equals, and hashCode
@AllArgsConstructor // Lombok annotation to generate a constructor with all fields
@NoArgsConstructor  // Lombok annotation to generate a no-argument constructor
public class AdminDTO {

    // Admin name must not be blank, must be alphabetic, and between 3 to 25 characters
    @NotBlank(message = "Name can not be empty")
    @Size(min = 3, max = 25, message = "First name must be between 3 and 25 characters")
    @Pattern(regexp = "^[A-Za-z]+$", message = "Name must contain only letters")
    private String name;

    // Username must not be blank
    @NotBlank(message = "Username can not be empty")
    private String userName;

    // Email must not be blank
    @NotBlank(message = "Email is mandatory")
    private String email;

    // Password must not be blank and must be at least 8 characters long
    @NotBlank(message = "Password is mandatory")
    @Size(min = 8, message = "Password must be at least 8 characters long")
    private String password;
}
