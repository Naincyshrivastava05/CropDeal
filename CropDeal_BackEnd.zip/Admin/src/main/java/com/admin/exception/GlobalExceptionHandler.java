package com.admin.exception;

import feign.FeignException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

/**
 * Global exception handler to manage and customize error responses across the application.
 */
@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    /**
     * Handles all uncaught exceptions.
     */
    @ExceptionHandler(Exception.class)
    public final ResponseEntity<ExceptionResponse> handleAllExceptions(Exception ex, WebRequest request) {
        ExceptionResponse response = new ExceptionResponse(
                LocalDate.now(),
                ex.getMessage(),
                request.getDescription(false),
                HttpStatus.INTERNAL_SERVER_ERROR.toString()
        );
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Handles exceptions thrown by Feign clients when calling other microservices.
     */
    @ExceptionHandler(FeignException.class)
    public ResponseEntity<ExceptionResponse> handleFeignException(FeignException ex) {
        String errorMessage = "An unexpected error occurred while processing the request.";

        if (ex.status() == HttpStatus.NOT_FOUND.value()) {
            String message = ex.getMessage();
            if (message != null && message.contains(":")) {
                errorMessage = message.substring(message.lastIndexOf(":") + 2).trim();
                if (errorMessage.startsWith("[") && errorMessage.endsWith("]")) {
                    errorMessage = errorMessage.substring(1, errorMessage.length() - 1).trim();
                }
            }
        } else if (ex.status() == HttpStatus.SERVICE_UNAVAILABLE.value()) {
            errorMessage = "The service is temporarily unavailable. Please try again later.";
        } else {
            String feignErrorMessage = ex.getMessage();
            if (feignErrorMessage != null) {
                errorMessage = feignErrorMessage;
            }
        }

        ex.printStackTrace(); // Optional: log stack trace for debugging

        ExceptionResponse response = new ExceptionResponse(
                LocalDate.now(),
                errorMessage,
                errorMessage,
                HttpStatus.INTERNAL_SERVER_ERROR.toString()
        );
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Handles runtime exceptions such as entity not found.
     */
    @ExceptionHandler(RuntimeException.class)
    public final ResponseEntity<ExceptionResponse> handleNotFoundException(RuntimeException ex, WebRequest request) {
        ExceptionResponse response = new ExceptionResponse(
                LocalDate.now(),
                ex.getMessage(),
                request.getDescription(false),
                HttpStatus.NOT_FOUND.toString()
        );
        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
    }

    /**
     * Handles validation errors for method arguments (e.g., @Valid).
     */
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex,
            HttpHeaders headers,
            HttpStatusCode status,
            WebRequest request) {

        Map<String, String> errors = new HashMap<>();

        // Collect field-specific validation errors
        ex.getBindingResult().getFieldErrors().forEach(error ->
                errors.put(error.getField(), error.getDefaultMessage())
        );

        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }
}
