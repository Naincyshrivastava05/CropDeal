package com.admin.feign;

import com.admin.model.Farmer;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name = "farmer-service")
public interface FarmerFeign {

    @GetMapping("api/farmers/getall")
    public ResponseEntity<List<Farmer>> getAll();

    @GetMapping("api/farmers/{id}")
    public ResponseEntity<Farmer> getById(@PathVariable int id);

    @DeleteMapping("api/farmers/delete/{id}")
    public ResponseEntity<Farmer> deleteById(@PathVariable int id);

}
