package com.admin.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * LoggingAspect is an Aspect-Oriented Programming (AOP) component
 * that logs method execution details for service layer methods.
 */
@Aspect
@Component
public class LoggingAspect {

    // Logger instance for logging method execution details
    private static final Logger logger = LoggerFactory.getLogger(LoggingAspect.class);

    /**
     * Pointcut that matches all methods in the service package.
     */
    @Pointcut("execution(* com.admin.services.service.*.*(..))")
    public void serviceMethods() {
        // Pointcut method - no implementation needed
    }

    /**
     * Logs method entry before the actual method execution.
     *
     * @param joinPoint provides reflective access to method details
     */
    @Before("serviceMethods()")
    public void logBeforeMethod(JoinPoint joinPoint) {
        logger.info("Entering method: {}", joinPoint.getSignature());
    }

    /**
     * Logs method exit and return value after successful execution.
     *
     * @param joinPoint provides method details
     * @param result    the returned object from the method
     */
    @AfterReturning(value = "serviceMethods()", returning = "result")
    public void logAfterReturning(JoinPoint joinPoint, Object result) {
        logger.info("Exiting method: {} | Return: {}", joinPoint.getSignature(), result);
    }

    /**
     * Logs execution time of the method using Around advice.
     *
     * @param joinPoint provides access to proceed with method execution
     * @return the result of the method execution
     * @throws Throwable if the method throws any exception
     */
    @Around("serviceMethods()")
    public Object logExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {
        long start = System.currentTimeMillis(); // Start time
        Object result = joinPoint.proceed();     // Proceed with method execution
        long executionTime = System.currentTimeMillis() - start; // Calculate duration
        logger.info("Method {} executed in {} ms", joinPoint.getSignature(), executionTime);
        return result;
    }

    /**
     * Logs any exception thrown by the method.
     *
     * @param joinPoint provides method details
     * @param exception the exception thrown
     */
    @AfterThrowing(value = "serviceMethods()", throwing = "exception")
    public void logAfterThrowing(JoinPoint joinPoint, Exception exception) {
        logger.error("Exception in method: {} | Message: {}", joinPoint.getSignature(), exception.getMessage());
    }
}
