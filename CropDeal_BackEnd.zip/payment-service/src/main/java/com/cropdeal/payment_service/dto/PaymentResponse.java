package com.cropdeal.payment_service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO returned to the client after processing a payment.
 * Contains metadata such as transaction ID, session URL, and payment status.
 */
@Data                        // Lombok: generates getters, setters, equals, hashCode, toString
@NoArgsConstructor           // Lombok: creates a no-argument constructor
@AllArgsConstructor          // Lombok: creates a constructor with all fields
@Builder                     // Lombok: enables fluent builder API
public class PaymentResponse {

    private String message;         // User-facing message (e.g. "Payment successful")
    private String transactionId;   // 🔄 Unique ID assigned to the transaction
    private String status;          // ✅ Status of payment (e.g. "Success", "Failed")
    private String sessionUrl;      // 🌐 URL to Stripe or other payment session, if applicable

    /**
     * Convenience constructor used for partial responses.
     *
     * @param paymentSuccessful Custom message string
     * @param s                 Transaction ID
     */
    public PaymentResponse(String paymentSuccessful, String s) {
        this.message = paymentSuccessful;
        this.transactionId = s;
    }
}