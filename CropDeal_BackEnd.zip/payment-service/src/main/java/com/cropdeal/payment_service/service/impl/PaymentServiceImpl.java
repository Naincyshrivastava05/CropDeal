package com.cropdeal.payment_service.service.impl;

import com.cropdeal.payment_service.dto.PaymentMessage;
import com.cropdeal.payment_service.dto.PaymentRequest;
import com.cropdeal.payment_service.dto.PaymentResponse;
import com.cropdeal.payment_service.entity.Payment;
import com.cropdeal.payment_service.feign.OrderClient;
import com.cropdeal.payment_service.message.PaymentPublisher;
import com.cropdeal.payment_service.repository.PaymentRepository;
import com.cropdeal.payment_service.service.PaymentService;
import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
 * Stripe-backed implementation of PaymentService.
 * Responsible for initiating payments, verifying transactions, and publishing payment events.
 */
@Slf4j
@Service
public class PaymentServiceImpl implements PaymentService {

    @Value("${stripe.secretKey}")
    private String secretKey; // Stripe API key injected from config

    @Autowired
    private PaymentRepository paymentRepo;

    @Autowired
    private OrderClient orderClient;  // Feign client to validate order existence

    @Autowired
    private PaymentPublisher paymentPublisher;  // Publishes messages to RabbitMQ queues

    /**
     * Handles successful Stripe payment session.
     * Updates internal payment record and publishes a success message to downstream services.
     *
     * @param session Stripe checkout session
     */
    public void handleStripeSuccess(Session session) {
        String orderId = session.getMetadata().get("orderId");
        String cropId = session.getMetadata().get("cropId");
        String quantityStr = session.getMetadata().get("quantity");

        PaymentMessage message = new PaymentMessage();
        message.setOrderId(orderId);
        message.setCropId(cropId);
        message.setQuantity(Integer.parseInt(quantityStr));
        message.setStatus("SUCCESS");

        Payment payment = paymentRepo.findBySessionId(session.getId());
        if (payment != null) {
            payment.setStatus("SUCCESS");
            paymentRepo.save(payment);
        }

        paymentPublisher.publishPaymentSuccess(message); // Notifies Order and Crop services
    }

    /**
     * Processes a payment request by validating order and initiating a Stripe session.
     * Persists session metadata and returns response to client.
     *
     * @param request Incoming payment request
     * @return PaymentResponse object containing session details or error info
     */
    @Override
    public PaymentResponse processPayment(PaymentRequest request) {
        log.info("Starting payment processing for: {}", request.getName());

        // Step 1: Validate the order ID via Feign client
        try {
            ResponseEntity<String> response = orderClient.checkOrderExists(request.getOrderId());
            if (!response.getStatusCode().is2xxSuccessful()) {
                return PaymentResponse.builder()
                        .status("FAILED")
                        .message("Order not found with ID: " + request.getOrderId())
                        .transactionId("N/A")
                        .sessionUrl("N/A")
                        .build();
            }
        } catch (Exception ex) {
            log.error("Order check failed: {}", ex.getMessage());
            return PaymentResponse.builder()
                    .status("FAILED")
                    .message("Order not found or Order Service unavailable for ID: " + request.getOrderId())
                    .transactionId("N/A")
                    .sessionUrl("N/A")
                    .build();
        }

        // Step 2: Configure Stripe session parameters
        Stripe.apiKey = secretKey;

        SessionCreateParams.LineItem.PriceData.ProductData productData =
                SessionCreateParams.LineItem.PriceData.ProductData.builder()
                        .setName(request.getName())
                        .build();

        SessionCreateParams.LineItem.PriceData priceData =
                SessionCreateParams.LineItem.PriceData.builder()
                        .setCurrency(request.getCurrency() == null ? "USD" : request.getCurrency())
                        .setUnitAmount(request.getAmount()) // amount in minor units (e.g., paise)
                        .setProductData(productData)
                        .build();

        SessionCreateParams.LineItem lineItem =
                SessionCreateParams.LineItem.builder()
                        .setQuantity(request.getQuantity())
                        .setPriceData(priceData)
                        .build();

        SessionCreateParams params = SessionCreateParams.builder()
                .setMode(SessionCreateParams.Mode.PAYMENT)
                .setSuccessUrl("http://localhost:8081/success")
                .setCancelUrl("http://localhost:8081/cancel")
                .addLineItem(lineItem)
                .putMetadata("orderId", request.getOrderId())
                .putMetadata("cropId", request.getCropId())
                .putMetadata("quantity", String.valueOf(request.getQuantity()))
                .build();

        // Step 3: Create Stripe session and persist payment
        try {
            Session session = Session.create(params);
            log.info("Stripe session created successfully: {}", session.getId());

            Payment payment = new Payment();
            payment.setOrderId(request.getOrderId());
            payment.setCropId(request.getCropId());
            payment.setQuantity(request.getQuantity());
            payment.setStatus("PENDING");
            payment.setSessionId(session.getId());
            payment.setCreatedAt(LocalDateTime.now());

            paymentRepo.save(payment);

            return PaymentResponse.builder()
                    .status("SUCCESS")
                    .message("Payment session created")
                    .transactionId(session.getId())
                    .sessionUrl(session.getUrl())
                    .build();

        } catch (StripeException ex) {
            log.error("StripeException occurred while creating session: {}", ex.getMessage(), ex);
            return PaymentResponse.builder()
                    .status("FAILED")
                    .message("Payment session creation failed")
                    .transactionId("N/A")
                    .sessionUrl("N/A")
                    .build();
        }
    }
}