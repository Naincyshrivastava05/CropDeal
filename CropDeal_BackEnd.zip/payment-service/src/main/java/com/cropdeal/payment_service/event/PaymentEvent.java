package com.cropdeal.payment_service.event;

import java.io.Serializable;

/**
 * Represents a lightweight event related to a payment transaction.
 * Used in event-driven components (e.g. RabbitMQ, Kafka) to signal status changes or actions.
 */
public class PaymentEvent implements Serializable {

    // Unique version ID for safe serialization during transmission
    private static final long serialVersionUID = 1L;

    private Long paymentId;    // 🔄 ID of the payment that triggered the event
    private String eventType;  // 📣 Type of event (e.g. "CREATED", "COMPLETED", "FAILED")

    /**
     * Constructor to initialize the event with payment ID and event type.
     *
     * @param paymentId ID of the payment
     * @param eventType Type of the event
     */
    public PaymentEvent(Long paymentId, String eventType) {
        this.paymentId = paymentId;
        this.eventType = eventType;
    }

    // Getter and Setter for paymentId
    public Long getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(Long paymentId) {
        this.paymentId = paymentId;
    }

    // Getter and Setter for eventType
    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }
}