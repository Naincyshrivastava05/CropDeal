package com.cropdeal.payment_service.controller;

import com.cropdeal.payment_service.dto.PaymentMessage;
import com.cropdeal.payment_service.dto.PaymentRequest;
import com.cropdeal.payment_service.dto.PaymentResponse;
import com.cropdeal.payment_service.message.PaymentPublisher;
import com.cropdeal.payment_service.service.PaymentService;
import com.cropdeal.payment_service.service.impl.PaymentServiceImpl;
import com.stripe.Stripe;
import com.stripe.model.checkout.Session;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * REST controller for managing payment operations.
 * Integrates with Stripe for checkout and handles asynchronous notifications via RabbitMQ.
 */
@Slf4j
@RestController
@RequestMapping("/api/payment")
public class PaymentController {

    private final PaymentServiceImpl stripeService;

    @Value("${stripe.secretKey}")
    private String secretKey;  // Stripe secret key injected from configuration

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private PaymentPublisher paymentPublisher;

    // Constructor injection for Stripe service implementation
    public PaymentController(PaymentServiceImpl service) {
        this.stripeService = service;
    }

    /**
     * Initiates the payment process and returns transaction metadata.
     *
     * @param request PaymentRequest object with order details and metadata
     * @return Stripe Checkout session details wrapped in a custom PaymentResponse
     */
    @PostMapping("/checkout")
    public ResponseEntity<PaymentResponse> makePayment(@RequestBody PaymentRequest request) {
        log.info("Received payment request: {}", request);
        PaymentResponse response = paymentService.processPayment(request);
        log.info("Payment processed with transaction ID: {}", response.getTransactionId());
        return ResponseEntity.ok(response);
    }

    /**
     * Basic health check endpoint to verify service availability.
     *
     * @return Simple status message
     */
    @GetMapping
    public ResponseEntity<String> getPayments() {
        log.info("Health check endpoint hit");
        return ResponseEntity.ok("Payments service is running!");
    }

    /**
     * Endpoint called after payment completion to publish a success event.
     *
     * @param paymentMessage Payload including order and transaction status
     * @return Confirmation message after event publication
     */
    @PostMapping("/success")
    public ResponseEntity<String> markPaymentSuccess(@RequestBody PaymentMessage paymentMessage) {
        paymentPublisher.publishPaymentSuccess(paymentMessage);
        return ResponseEntity.ok("Payment marked as successful for order " + paymentMessage.getOrderId());
    }

    /**
     * Verifies payment status using Stripe session ID.
     *
     * @param sessionId Stripe Checkout session ID
     * @return Confirmation of payment status or error details
     */
    @GetMapping("/payment/verify")
    public ResponseEntity<String> verifyPayment(@RequestParam String sessionId) {
        try {
            Stripe.apiKey = secretKey;
            Session session = Session.retrieve(sessionId);

            if ("paid".equals(session.getPaymentStatus())) {
                paymentService.handleStripeSuccess(session);
                return ResponseEntity.ok("Payment verified and order updated");
            } else {
                return ResponseEntity.ok("Payment not completed yet");
            }
        } catch (Exception e) {
            return ResponseEntity.status(400).body("Error verifying payment: " + e.getMessage());
        }
    }
}