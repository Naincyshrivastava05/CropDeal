package com.cropdeal.payment_service.config;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * RabbitMQ configuration class for the Payment Service.
 * Defines exchanges, queues, bindings, and components to send/receive messages with JSON conversion.
 */
@Configuration
public class RabbitMQConfig {

    // ⛳ ORDER SERVICE (existing integration)
    @Value("${rabbitmq.order.exchange}")
    private String orderExchangeName;

    @Value("${rabbitmq.order.queue}")
    private String orderQueueName;

    @Value("${rabbitmq.order.routingkey}")
    private String orderRoutingKey;

    // 🌾 CROP SERVICE (new integration)
    @Value("${rabbitmq.crop.exchange}")
    private String cropExchangeName;

    @Value("${rabbitmq.crop.queue}")
    private String cropQueueName;

    @Value("${rabbitmq.crop.routingkey}")
    private String cropRoutingKey;

    // ─── Declare Topic Exchanges ────────────────────────────────────────────────

    /**
     * TopicExchange for communicating with Order Service.
     */
    @Bean
    public TopicExchange orderExchange() {
        return new TopicExchange(orderExchangeName, true, false);
    }

    /**
     * TopicExchange for communicating with Crop Service.
     */
    @Bean
    public TopicExchange cropExchange() {
        return new TopicExchange(cropExchangeName, true, false);
    }

    // ─── Declare Durable Queues ─────────────────────────────────────────────────

    /**
     * Durable queue for Order Service messages.
     */
    @Bean
    public Queue orderQueue() {
        return QueueBuilder.durable(orderQueueName).build();
    }

    /**
     * Durable queue for Crop Service messages.
     */
    @Bean
    public Queue cropQueue() {
        return QueueBuilder.durable(cropQueueName).build();
    }

    // ─── Bind Queues to Exchanges with Routing Keys ─────────────────────────────

    /**
     * Binds the orderQueue to the orderExchange with the specified routing key.
     */
    @Bean
    public Binding orderBinding() {
        return BindingBuilder
                .bind(orderQueue())
                .to(orderExchange())
                .with(orderRoutingKey);
    }

    /**
     * Binds the cropQueue to the cropExchange with the specified routing key.
     */
    @Bean
    public Binding cropBinding() {
        return BindingBuilder
                .bind(cropQueue())
                .to(cropExchange())
                .with(cropRoutingKey);
    }

    // ─── Admin + JSON Messaging Template ────────────────────────────────────────

    /**
     * AMQP admin to declare queues, exchanges, and bindings at runtime.
     */
    @Bean
    public AmqpAdmin rabbitAdmin(ConnectionFactory cf) {
        return new RabbitAdmin(cf);
    }

    /**
     * Converts messages to and from JSON format using Jackson.
     */
    @Bean
    public MessageConverter jsonConverter() {
        return new Jackson2JsonMessageConverter();
    }

    /**
     * RabbitTemplate configured to use JSON message converter for publishing.
     */
    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory cf, MessageConverter converter) {
        RabbitTemplate tpl = new RabbitTemplate(cf);
        tpl.setMessageConverter(converter);
        return tpl;
    }
}