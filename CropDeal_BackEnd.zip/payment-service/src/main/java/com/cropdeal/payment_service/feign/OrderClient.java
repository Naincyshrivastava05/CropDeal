package com.cropdeal.payment_service.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Feign client interface to communicate with the Order Service.
 * Used to verify the existence of an order using its unique ID.
 * The service is expected to run on localhost port 8087.
 */
@FeignClient(name = "orderservice", url = "http://localhost:8087")
public interface OrderClient {

    /**
     * Sends a GET request to the Order Service to check if an order exists.
     *
     * @param orderId ID of the order to verify
     * @return ResponseEntity containing confirmation or error message
     */
    @GetMapping("/orders/{orderId}")
    ResponseEntity<String> checkOrderExists(@PathVariable("orderId") String orderId);
}