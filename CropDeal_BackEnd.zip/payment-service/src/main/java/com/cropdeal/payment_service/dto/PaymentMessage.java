package com.cropdeal.payment_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * DTO representing a payment message sent through RabbitMQ.
 * Used to update order and crop services after payment events.
 */
@Data                      // Lombok: auto-generates getters, setters, toString, equals, and hashCode
@AllArgsConstructor        // Lombok: creates constructor with all fields
@NoArgsConstructor         // Lombok: creates no-argument constructor
public class PaymentMessage implements Serializable {

    private String orderId;   // ID of the order linked to the payment
    private String cropId;    // Crop ID involved in the transaction
    private int quantity;     // Quantity of crop ordered
    private String status;    // Payment status (e.g. "SUCCESS", "FAILED")

}