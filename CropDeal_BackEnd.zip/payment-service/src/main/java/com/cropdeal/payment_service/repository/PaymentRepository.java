package com.cropdeal.payment_service.repository;

import com.cropdeal.payment_service.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository interface for accessing and managing Payment entities in the database.
 * Extends JpaRepository to provide basic CRUD operations and custom query methods.
 */
public interface PaymentRepository extends JpaRepository<Payment, Long> {

    /**
     * Retrieves a Payment entity by its Stripe or external session ID.
     * Useful for verifying payment status or reconciling transactions.
     *
     * @param sessionId Unique payment session identifier
     * @return Payment entity matching the session ID
     */
    Payment findBySessionId(String sessionId);
}