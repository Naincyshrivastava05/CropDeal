package com.cropdeal.payment_service.message;

import com.cropdeal.payment_service.dto.PaymentMessage;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Publishes payment success messages to multiple RabbitMQ queues.
 * This class routes messages to both Order and Crop services after a successful payment.
 */
@Component
public class PaymentPublisher {

    @Autowired
    private AmqpTemplate rabbitTemplate;  // Template for sending messages to RabbitMQ

    // Configuration for Order Service routing
    @Value("${rabbitmq.order.exchange}")
    private String orderExchange;

    @Value("${rabbitmq.order.routingkey}")
    private String orderRoutingKey;

    // Configuration for Crop Service routing
    @Value("${rabbitmq.crop.exchange}")
    private String cropExchange;

    @Value("${rabbitmq.crop.routingkey}")
    private String cropRoutingKey;

    /**
     * Publishes a PaymentMessage to both Order and Crop services via RabbitMQ.
     * Uses separate exchanges and routing keys for service-specific targeting.
     *
     * @param message The PaymentMessage object containing transaction metadata
     */
    public void publishPaymentSuccess(PaymentMessage message) {
        // 📦 Notify Order Service with payment confirmation
        rabbitTemplate.convertAndSend(orderExchange, orderRoutingKey, message);
        System.out.println("Published to ORDER queue for order " + message.getOrderId());

        // 🌾 Notify Crop Service to update inventory or availability
        rabbitTemplate.convertAndSend(cropExchange, cropRoutingKey, message);
        System.out.println("Published to CROP queue for cropId " + message.getCropId());
    }
}