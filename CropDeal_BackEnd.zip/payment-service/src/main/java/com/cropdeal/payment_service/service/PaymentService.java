package com.cropdeal.payment_service.service;

import com.cropdeal.payment_service.dto.PaymentRequest;
import com.cropdeal.payment_service.dto.PaymentResponse;
import com.stripe.model.checkout.Session;

public interface PaymentService {
    PaymentResponse processPayment(PaymentRequest request);
    public void handleStripeSuccess(Session session);
}
