package com.cropdeal.payment_service.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * DTO representing a payment initiation request.
 * This object is used to start a Stripe Checkout session or other payment flow.
 */
@Getter                         // Lombok: generates getters for all fields
@Setter                         // Lombok: generates setters for all fields
@AllArgsConstructor             // Lombok: constructor with all args
@NoArgsConstructor              // Lombok: no-arg constructor
public class PaymentRequest {

    public Long amount;         // 💰 Total amount to be paid (likely in minor units like paise or cents)

    private Long quantity;      // 🌾 Quantity of crop being purchased

    private String name;        // 🧾 Name of the crop or item

    private String currency;    // 💱 Currency code (e.g., "INR", "USD")

    private Long farmerId;      // 👨‍🌾 ID of the farmer selling the crop

    private Long dealerId;      // 🧑‍💼 ID of the dealer placing the order

    private String orderId;     // 📦 Unique identifier for the order

    private String cropId;      // 🌱 Identifier for the crop being purchased
}