package com.cropdeal.payment_service.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * Represents a payment transaction in the CropDeal system.
 * Stores essential metadata for verifying and tracking payment status.
 */
@Entity                   // Marks this class as a JPA entity mapped to a database table
@Getter                   // Lombok: generates getters for all fields
@Setter                   // Lombok: generates setters for all fields
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;          // Primary key (auto-incremented)

    private String orderId;   // ID of the order associated with this payment

    private String cropId;    // ID of the crop being purchased

    private Long quantity;    // Quantity of crop included in the order

    private String status;    // Payment status (e.g. "Success", "Failed", "Pending")

    private String sessionId; // Stripe or third-party session identifier

    private LocalDateTime createdAt; // Timestamp of when the payment was initiated/recorded
}
