package com.authentication_service.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.*;
import java.util.function.Function;

@Component
public class JwtUtil {

    @Value("${jwt.secret}")
    private String secretKey;

    private Key key;
    // Token valid for 10 hours
    private static final long EXPIRATION_TIME = 1000 * 60 * 60 * 10;
    @PostConstruct
    public void initKey() {
        // Decode the Base64 encoded secret key
        key = Keys.hmacShaKeyFor(Base64.getDecoder().decode(secretKey));
    }
    // Generate a new JWT token with username as subject, roles, and userId claims
    public String generateToken(String username, Long id, List<String> roles) {
        return Jwts.builder()
                .setSubject(username)  // setting the main subject to username
                .claim("role", roles)  // storing list of roles (without any ROLE_ prefix)
                .claim("userId", id)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();
    }
    // Extract the username from the token's subject
    public String extractUsername(String token){
        return extractClaim(token, Claims::getSubject);
    }

    // Extract the roles claim. Returns an empty list if not found.
    public List<String> extractRoles(String token) {
        Claims claims = extractAllClaims(token);
        List<String> roles = claims.get("role", List.class);
        return roles != null ? roles : Collections.emptyList();
    }

    // Utility to extract any claim
    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        return claimsResolver.apply(extractAllClaims(token));
    }

    // Get all claims from the token
    private Claims extractAllClaims(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    // Validate the token by comparing the username and checking expiration
    public Boolean validateToken(String token, String username) {
        try {
            final String tokenUsername = extractUsername(token);
            return (tokenUsername.equals(username) && !isTokenExpired(token));
        } catch (JwtException | IllegalArgumentException e) {
            return false;
        }
    }



    // Check if the token is expired
    private boolean isTokenExpired(String token) {
        return extractAllClaims(token).getExpiration().before(new Date());
    }
}