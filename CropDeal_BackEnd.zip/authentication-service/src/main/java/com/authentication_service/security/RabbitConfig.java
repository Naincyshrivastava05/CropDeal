package com.authentication_service.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitConfig {

    private static final Logger log = LoggerFactory.getLogger(RabbitConfig.class);

    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
        //Stores rabbitMQ connection setting
        RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);

        // Enable publisher confirmations
        rabbitTemplate.setConfirmCallback((correlationData, ack, cause) -> {
            if (!ack) {
                log.error("Message not delivered: {}", cause);
            }
        });

        // Optionally, add a return callback if using mandatory flag
        rabbitTemplate.setReturnsCallback(returned -> {
            log.error("Returned Message: {} with replyCode: {} and replyText: {}",
                    returned.getMessage(),
                    returned.getReplyCode(),
                    returned.getReplyText());
        });
        return rabbitTemplate;
    }
}