package com.authentication_service.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.io.Serializable;

/**
 * Data Transfer Object for user registration and authentication.
 */
public class UserDTO implements Serializable {

    // Username must not be blank
    @NotBlank(message = "Username is required")
    private String username;

    // Email must not be blank and must be a valid format
    @NotBlank(message = "Email is required")
    @Email(message = "Email should be valid")
    private String email;

    // Password must not be blank and must be at least 6 characters long
    @NotBlank(message = "Password is required")
    @Size(min = 6, message = "Password must be at least 6 characters long")
    private String password;

    // Confirm password must not be blank
    @NotBlank(message = "Confirm Password is required")
    private String confirmPassword;

    // Role must not be blank (e.g., FARMER, DEALER, ADMIN)
    @NotBlank(message = "Role is required")
    private String role;

    // Getter for username
    public String getUsername() {
        return username;
    }

    // Setter for username
    public void setUsername(String username) {
        this.username = username;
    }

    // Getter for email
    public String getEmail() {
        return email;
    }

    // Setter for email
    public void setEmail(String email) {
        this.email = email;
    }

    // Getter for password
    public String getPassword() {
        return password;
    }

    // Setter for password
    public void setPassword(String password) {
        this.password = password;
    }

    // Getter for confirmPassword
    public String getConfirmPassword() {
        return confirmPassword;
    }

    // Setter for confirmPassword
    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    // Getter for role
    public String getRole() {
        return role;
    }

    // Setter for role
    public void setRole(String role) {
        this.role = role;
    }
}
