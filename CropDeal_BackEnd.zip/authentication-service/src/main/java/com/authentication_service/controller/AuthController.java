package com.authentication_service.controller;

import com.authentication_service.dto.UserDTO;
import com.authentication_service.model.User;
import com.authentication_service.repository.UserRepository;
import com.authentication_service.security.JwtUtil;
import com.authentication_service.service.RegistrationService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Controller for handling authentication and registration requests.
 */
@RestController
@RequestMapping("/auth")
public class AuthController {

    // Map to hold role-specific registration URLs
    private final Map<String, String> roleServiceUrlMap = Map.of(
            "FARMER", "http://localhost:8080/api/farmers/register",
            "DEALER", "http://localhost:8082/api/dealers/register"
    );

    @Autowired
    private JwtUtil jwtUtil; // Utility for generating JWT tokens

    @Autowired
    private PasswordEncoder passwordEncoder; // Password encoder for secure password comparison

    @Autowired
    private UserRepository userRepository; // Repository to access user data

    @Autowired
    private RegistrationService service; // Service to handle registration logic

    @Autowired
    private WebClient.Builder webClientBuilder; // WebClient builder for making HTTP requests

    // Endpoint to register a new user
    @PostMapping("/signup")
    public ResponseEntity<?> registerUser(@Valid @RequestBody UserDTO userDTO) {
        // Check if passwords match
        if (!userDTO.getPassword().equals(userDTO.getConfirmPassword())) {
            return ResponseEntity.badRequest().body("Passwords do not match.");
        }

        // Prevent public registration for Admin role
        if ("ADMIN".equalsIgnoreCase(userDTO.getRole())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body("Admin registration is not allowed via public API.");
        }

        // Register user in authentication service
        service.register(userDTO);

        // Get target service URL based on role
        String role = userDTO.getRole().toUpperCase();
        String targetUrl = roleServiceUrlMap.get(role);

        // Validate role and route registration to appropriate service
        if (targetUrl == null) {
            return ResponseEntity.badRequest().body("Invalid role: " + role);
        }

        try {
            // Forward registration request to the respective microservice
            String response = webClientBuilder.build()
                    .post()
                    .uri(targetUrl)
                    .bodyValue(userDTO)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            return ResponseEntity.ok(Map.of("message", "Forwarded to " + role + " service", "response", response));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error routing to " + role + " service: " + e.getMessage());
        }
    }

    // Endpoint to authenticate a user and return a JWT token
    @PostMapping("/login")
    public ResponseEntity<Map<String, String>> login(@Valid @RequestBody Map<String, String> credentials) {
        String username = credentials.get("username");
        String password = credentials.get("password");

        // Find user by username
        Optional<User> optionalUser = userRepository.findByUsername(username);

        if (optionalUser.isPresent()) {
            User user = optionalUser.get();

            // Check if password matches
            boolean match = passwordEncoder.matches(password, user.getPassword());

            // Debug logs (optional, remove in production)
            System.out.println("Login raw password: " + password);
            System.out.println("Stored hash: " + user.getPassword());
            System.out.println("Password matches: " + match);

            if (match) {
                String token = jwtUtil.generateToken(user.getUsername(), user.getId(), List.of(user.getRole()));
                return ResponseEntity.ok(Map.of("token", token, "role", user.getRole()));
            }
        }

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Invalid credentials"));
    }
}