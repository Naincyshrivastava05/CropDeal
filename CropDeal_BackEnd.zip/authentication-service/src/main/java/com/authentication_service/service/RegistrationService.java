package com.authentication_service.service;

import com.authentication_service.dto.UserDTO;
import com.authentication_service.model.User;
import com.authentication_service.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

/**
 * Service class responsible for handling user registration logic.
 */
@Slf4j
@Service
public class RegistrationService {

    @Autowired
    private UserRepository userRepository; // Repository to persist user data

    @Autowired
    private PasswordEncoder passwordEncoder; // Encoder for hashing passwords

    @Autowired
    private RabbitTemplate rabbitTemplate; // RabbitMQ template for sending messages

    /**
     * Registers a new user and forwards the registration to the appropriate service via RabbitMQ.
     */
    public ResponseEntity<?> register(UserDTO userDTO) {
        log.info("Received registration request for username: {}", userDTO.getUsername());

        try {
            // Check if the username already exists
            if (userRepository.findByUsername(userDTO.getUsername()).isPresent()) {
                return ResponseEntity.status(HttpStatus.CONFLICT).body("Username already exists.");
            }

            // Encode the password before saving
            String encodedPassword = passwordEncoder.encode(userDTO.getPassword());

            // Create a new User entity from the DTO
            User user = User.builder()
                    .username(userDTO.getUsername())
                    .email(userDTO.getEmail())
                    .password(encodedPassword)
                    .role(userDTO.getRole())
                    .build();

            // Save the user to the database
            userRepository.save(user);

            // Update the DTO with the encoded password before sending
            userDTO.setPassword(encodedPassword);

            // Construct the routing key based on the user's role
            String routingKey = "gateway.registration." + userDTO.getRole().toLowerCase();

            // Send the registration message to the appropriate service via RabbitMQ
            rabbitTemplate.convertAndSend("gateway.exchange", routingKey, userDTO);
            log.info("Message published to RabbitMQ with routing key: {}", routingKey);

            return ResponseEntity.ok("User registration request received and forwarded for " + userDTO.getRole() + ".");
        } catch (Exception e) {
            log.error("Failed to publish registration message: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error publishing registration request.");
        }
    }
}
