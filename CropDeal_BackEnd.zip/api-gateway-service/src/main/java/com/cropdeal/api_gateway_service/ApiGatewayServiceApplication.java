package com.cropdeal.api_gateway_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * Main class for starting the API Gateway service.
 */
@SpringBootApplication(
        exclude = {
                // Exclude security auto-configuration for actuator endpoints in reactive apps
                org.springframework.boot.actuate.autoconfigure.security.reactive.ReactiveManagementWebSecurityAutoConfiguration.class,
                // Exclude DataSource auto-configuration since this service doesn't use a database
                DataSourceAutoConfiguration.class
        }
)
@EnableDiscoveryClient // Enables service registration with Eureka or other discovery services
public class ApiGatewayServiceApplication {

    // Main method to launch the Spring Boot application
    public static void main(String[] args) {
        SpringApplication.run(ApiGatewayServiceApplication.class, args);
    }
}
