package com.cropdeal.api_gateway_service.config;

import org.springframework.core.convert.converter.Converter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Custom converter to extract roles from JWT claims and convert them into Spring Security authorities.
 */
public class CustomJwtGrantedAuthoritiesConverter implements Converter<Jwt, Collection<GrantedAuthority>> {

    // Converts JWT claims into a collection of GrantedAuthority
    @Override
    public Collection<GrantedAuthority> convert(Jwt jwt) {
        // Extract the "role" claim as a list of strings
        List<String> roles = jwt.getClaimAsStringList("role");

        // Return an empty list if no roles are found
        if (roles == null) {
            return List.of();
        }

        // Prefix each role with "ROLE_" and convert to SimpleGrantedAuthority
        return roles.stream()
                .map(role -> "ROLE_" + role) // Add Spring Security role prefix
                .map(SimpleGrantedAuthority::new) // Convert to GrantedAuthority
                .collect(Collectors.toList()); // Collect into a list
    }
}
