package com.cropdeal.api_gateway_service.config;

import org.springframework.amqp.core.Queue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration class for defining RabbitMQ queues used by the API Gateway.
 */
@Configuration
public class RabbitMQConfig {

    // Declares a durable queue named "gateway.registration.queue"
    @Bean
    public Queue registrationQueue() {
        // 'true' means the queue is durable (will survive broker restarts)
        return new Queue("gateway.registration.queue", true);
    }
}
