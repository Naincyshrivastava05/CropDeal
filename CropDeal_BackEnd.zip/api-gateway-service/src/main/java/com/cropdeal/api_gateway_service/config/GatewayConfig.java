package com.cropdeal.api_gateway_service.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration class for defining routes in the Spring Cloud Gateway.
 */
@Configuration
public class GatewayConfig {

    // Bean to define routing rules for different microservices
    @Bean
    public RouteLocator routes(RouteLocatorBuilder builder) {
        return builder.routes()
                // Route for Farmer Service
                .route("farmer-service", r -> r.path("/api/farmers/**")
                        .uri("http://localhost:8080"))
                // Route for Dealer Service
                .route("dealer-service", r -> r.path("/api/dealers/**")
                        .uri("http://localhost:8082"))
                // Route for Admin Service
                .route("admin-service", r -> r.path("/Admin/**")
                        .uri("http://localhost:7499"))
                .build(); // Build and return the route configuration
    }
}
