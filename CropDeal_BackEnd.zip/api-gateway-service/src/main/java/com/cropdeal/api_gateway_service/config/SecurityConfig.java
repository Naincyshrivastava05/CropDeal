package com.cropdeal.api_gateway_service.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.NimbusReactiveJwtDecoder;
import org.springframework.security.oauth2.jwt.ReactiveJwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.ReactiveJwtAuthenticationConverterAdapter;
import org.springframework.security.web.server.SecurityWebFilterChain;
import reactor.core.publisher.Mono;

import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

/**
 * Security configuration for the API Gateway using Spring WebFlux and JWT authentication.
 */
@Configuration
@EnableWebFluxSecurity
public class SecurityConfig {

    // Bean to decode JWT tokens using a secret key
    @Bean
    public ReactiveJwtDecoder jwtDecoder() {
        // Decode the Base64-encoded secret key
        byte[] secretBytes = Base64.getDecoder().decode("v87f21uzR8BoL63GmpYYGVR7EaSuIJ71RuGF0EZRW4uACvvUwM6OigKoob0r8fg/");
        SecretKeySpec secretKey = new SecretKeySpec(secretBytes, "HmacSHA256");
        return NimbusReactiveJwtDecoder.withSecretKey(secretKey).build(); // Build the JWT decoder
    }

    // Bean to configure the security filter chain for handling HTTP requests
    @Bean
    public SecurityWebFilterChain securityWebFilterChain(ServerHttpSecurity http) {
        return http
                .csrf(ServerHttpSecurity.CsrfSpec::disable) // Disable CSRF for stateless APIs
                .authorizeExchange(exchanges -> exchanges
                        .pathMatchers("/auth/**").permitAll() // Allow unauthenticated access to /auth endpoints
                        .pathMatchers(HttpMethod.OPTIONS).permitAll() // Allow preflight CORS requests
                        .pathMatchers("/api/farmers/**").hasRole("FARMER") // Restrict farmer APIs to FARMER role
                        .pathMatchers("/api/dealers/**").hasRole("DEALER") // Restrict dealer APIs to DEALER role
                        .pathMatchers("/admin/**").hasRole("ADMIN") // Restrict admin APIs to ADMIN role
                        .anyExchange().authenticated() // All other requests require authentication
                )
                .oauth2ResourceServer(oauth2 -> oauth2
                        .jwt(jwt -> jwt.jwtAuthenticationConverter(reactiveJwtAuthenticationConverter())) // Use custom JWT converter
                )
                .build(); // Build the security filter chain
    }

    // Bean to convert JWT claims into Spring Security authorities
    @Bean
    public Converter<Jwt, Mono<AbstractAuthenticationToken>> reactiveJwtAuthenticationConverter() {
        JwtAuthenticationConverter converter = new JwtAuthenticationConverter();
        converter.setJwtGrantedAuthoritiesConverter(new CustomJwtGrantedAuthoritiesConverter()); // Set custom authority converter
        return new ReactiveJwtAuthenticationConverterAdapter(converter); // Adapt to reactive context
    }
}
