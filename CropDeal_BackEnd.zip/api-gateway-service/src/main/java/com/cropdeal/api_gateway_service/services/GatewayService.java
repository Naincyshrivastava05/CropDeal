package com.cropdeal.api_gateway_service.services;

import com.authentication_service.dto.UserDTO;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Service class to handle user registration messages from RabbitMQ and route them to appropriate services.
 */
@Service
public class GatewayService {

    // Injecting RabbitTemplate to send messages to RabbitMQ
    @Autowired
    private RabbitTemplate rabbitTemplate;

    // Listener method to consume messages from the registration queue
    @RabbitListener(queues = "gateway.registration.queue")
    public void handleRegistration(UserDTO userDTO) {
        // Construct routing key based on user role (e.g., registration.farmer)
        String routingKey = "registration." + userDTO.getRole().toLowerCase();

        // Send the userDTO to the appropriate service via RabbitMQ exchange
        rabbitTemplate.convertAndSend("registration.exchange", routingKey, userDTO);
    }
}
