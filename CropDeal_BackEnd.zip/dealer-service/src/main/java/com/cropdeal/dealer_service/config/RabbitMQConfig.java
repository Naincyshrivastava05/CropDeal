package com.cropdeal.dealer_service.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * RabbitMQ configuration class for Dealer Service.
 * Defines queue, exchange, and binding for message routing.
 */
@Configuration
public class RabbitMQConfig {

    /**
     * Declares a TopicExchange named 'registration.exchange'.
     * Topic exchanges route messages based on matching routing patterns.
     */
    @Bean
    public TopicExchange exchange() {
        return new TopicExchange("registration.exchange");
    }

    /**
     * Declares a queue named 'registration.dealer.queue'.
     * This queue will receive registration messages for dealer profiles.
     */
    @Bean
    public Queue farmerQueue() {
        return new Queue("registration.dealer.queue");
    }

    /**
     * Binds the dealer queue to the topic exchange with the routing key 'registration.dealer'.
     * Ensures that only messages with this key are delivered to the dealer queue.
     */
    @Bean
    public Binding farmerBinding(Queue farmerQueue, TopicExchange exchange) {
        return BindingBuilder.bind(farmerQueue)
                .to(exchange)
                .with("registration.dealer");
    }
}