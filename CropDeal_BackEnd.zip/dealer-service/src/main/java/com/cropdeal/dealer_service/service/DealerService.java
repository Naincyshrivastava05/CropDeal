package com.cropdeal.dealer_service.service;

import com.cropdeal.dealer_service.dto.UserDTO;
import com.cropdeal.dealer_service.model.Dealer;
import com.cropdeal.dealer_service.repository.DealerRepository;
import jakarta.persistence.EntityNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.naming.directory.InvalidAttributesException;
import java.util.List;

/**
 * Service layer for handling Dealer operations such as registration,
 * retrieval, update, deletion, and RabbitMQ message consumption.
 */
@Service
public class DealerService {

    private static final Logger logger = LoggerFactory.getLogger(DealerService.class);

    @Autowired
    private DealerRepository repository;

    /**
     * Registers and saves a new dealer to the database.
     *
     * @param dealer Dealer entity to be persisted
     * @return Persisted dealer instance
     */
    public Dealer addDealer(Dealer dealer) {
        logger.info("Adding dealer: {}", dealer);
        return repository.save(dealer);
    }

    /**
     * Retrieves all dealer entries from the database.
     *
     * @return List of Dealer entities
     */
    public List<Dealer> getAllDealers() {
        logger.info("Fetching all dealers");
        return repository.findAll();
    }

    /**
     * Fetches a dealer by their ID.
     * Throws an exception if dealer is not found.
     *
     * @param id Dealer ID
     * @return Dealer entity
     */
    public Dealer getDealerById(Long id) {
        logger.info("Fetching dealer with ID: {}", id);
        return repository.findById(id).orElseThrow(() -> {
            logger.warn("Dealer not found with ID: {}", id);
            return new EntityNotFoundException("Dealer not found with id " + id);
        });
    }

    /**
     * Updates an existing dealer's name and email based on ID.
     *
     * @param id     ID of dealer to update
     * @param dealer New dealer data to apply
     * @return Updated Dealer entity
     */
    public Dealer updateDealer(Long id, Dealer dealer) {
        logger.info("Updating dealer with ID: {}", id);
        Dealer existing = getDealerById(id);
        existing.setName(dealer.getName());
        existing.setEmail(dealer.getEmail());
        Dealer updated = repository.save(existing);
        logger.debug("Updated dealer: {}", updated);
        return updated;
    }

    public Dealer updateDealerByName(String username, Dealer dealer) throws InvalidAttributesException {
        Dealer existing = repository.findByName(username);
        existing.setName(dealer.getName());
        existing.setEmail(dealer.getEmail());
        Dealer updated = repository.save(existing);
        logger.debug("Updated dealer: {}", updated);
        return updated;
    }

    public Dealer getDealerByName(String username) {
        return repository.findByName(username);
    }

    /**
     * Deletes a dealer by ID.
     * Throws an InvalidAttributesException if the dealer is not found.
     *
     * @param id ID of dealer to delete
     * @return Deleted Dealer entity
     * @throws InvalidAttributesException if dealer doesn't exist
     */
    public Dealer deleteDealer(Long id) throws InvalidAttributesException {
        logger.info("Deleting dealer with ID: {}", id);
        Dealer dealer = repository.findById(id).orElseThrow(() -> new InvalidAttributesException());
        repository.delete(dealer);
        logger.info("Dealer with ID {} deleted successfully", id);
        return dealer;
    }

    /**
     * RabbitMQ listener that receives farmer registration messages.
     * Repurposes data into a Dealer object—placeholder logic for demo or cross-registration.
     *
     * @param dto Incoming UserDTO message from queue
     */
    @RabbitListener(queues = "registration.farmer.queue")
    public void receiveFarmerRegistration(UserDTO dto) {
        Dealer dealer = new Dealer();
        dealer.setName(dto.getUsername());
        dealer.setEmail(dto.getEmail());
        // 🔄 You could expand this logic to check for duplicates or map roles dynamically
        repository.save(dealer);
    }
}