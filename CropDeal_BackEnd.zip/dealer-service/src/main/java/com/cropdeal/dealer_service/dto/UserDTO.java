package com.cropdeal.dealer_service.dto;

import java.io.Serializable;

/**
 * Data Transfer Object for user registration and role assignment.
 * Implements Serializable to allow transmission over network (e.g., RabbitMQ).
 */
public class UserDTO implements Serializable {

    private String username;          // User's display name or login name
    private String email;             // Email ID for contact and authentication
    private String password;          // Encrypted password for security
    private String confirmPassword;   // Used for validating password input (typically checked on the frontend or in service layer)
    private String role;              // Role designation (e.g., "DEALER", "FARMER", "ADMIN")

    // Getter and Setter for username
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    // Getter and Setter for email
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Getter and Setter for password
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // Getter and Setter for confirmPassword
    public String getConfirmPassword() {
        return confirmPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    // Getter and Setter for role
    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}