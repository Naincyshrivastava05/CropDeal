package com.cropdeal.dealer_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Dealer entity mapped to a relational database using JPA annotations.
 * Represents a dealer who registers with the CropDeal system.
 */
@Entity                    // Marks this class as a JPA entity
@Data                      // Lombok annotation to auto-generate getters, setters, toString, etc.
@AllArgsConstructor        // Lombok: generates constructor with all fields
@NoArgsConstructor         // Lombok: generates default no-arg constructor
public class Dealer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // Auto-generates unique ID for each dealer
    private Long id;

    @NotBlank(message = "Name is mandatory")             // Validates that name is not null or empty
    private String name;

    @Email(message = "Email should be valid")            // Ensures proper email format
    @Column(unique = true, nullable = false)             // Email must be unique and non-null in DB
    private String email;

    @NotBlank(message = "Password is required")          // Password must not be empty
    private String password;

    private String role;                                 // Role can specify access level or type (e.g., DEALER, ADMIN)
}