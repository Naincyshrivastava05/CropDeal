package com.cropdeal.dealer_service.controller;

import com.cropdeal.dealer_service.model.Dealer;
import com.cropdeal.dealer_service.service.DealerService;
import com.cropdeal.farmer_service.dto.UserDTO;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.naming.directory.InvalidAttributesException;

/**
 * REST controller for managing Dealer-related operations.
 * Handles registration, retrieval, and updates for Dealer entities.
 */
@RestController
@RequestMapping("/api/dealers")
public class DealerController {

    private static final Logger logger = LoggerFactory.getLogger(DealerController.class);

    @Autowired
    private DealerService service;

    /**
     * Registers a new dealer using provided user details.
     * Expects a valid UserDTO object with username, email, password, and role.
     *
     * @param userDTO Details of the dealer to be registered
     * @return Success message upon dealer registration
     */
    @PostMapping("/register")
    public ResponseEntity<?> createFarmer(@Valid @RequestBody UserDTO userDTO) {
        Dealer dealer = new Dealer();
        dealer.setName(userDTO.getUsername());
        dealer.setEmail(userDTO.getEmail());
        dealer.setPassword(userDTO.getPassword()); // Password assumed to be already encoded
        dealer.setRole(userDTO.getRole());

        service.addDealer(dealer);
        return ResponseEntity.ok("Dealer registered");
    }

    /**
     * Retrieves dealer information by unique dealer ID.
     *
     * @param id Dealer ID
     * @return Dealer object if found
     */
    @GetMapping("/get/{id}")
    public ResponseEntity<Dealer> getById(@PathVariable Long id) {
        logger.info("Received request to fetch dealer with ID: {}", id);
        return ResponseEntity.ok(service.getDealerById(id));
    }

    /**
     * Updates an existing dealer's details using the given ID.
     * Dealer object is validated before applying changes.
     *
     * @param id     ID of the dealer to update
     * @param dealer Updated dealer details
     * @return Updated Dealer object
     */
    @PutMapping("/{id}")
    public ResponseEntity<Dealer> update(@PathVariable Long id, @Valid @RequestBody Dealer dealer) {
        logger.info("Received request to update dealer with ID: {}", id);
        return ResponseEntity.ok(service.updateDealer(id, dealer));
    }

    @GetMapping("/{name}")
    public ResponseEntity<Dealer> getByName(@PathVariable String name) throws InvalidAttributesException {
        logger.info("Recieve request to get dealer with Username: {}", name);
        return new ResponseEntity<>(service.getDealerByName(name), HttpStatus.OK);
    }
}