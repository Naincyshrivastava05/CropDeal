// import RegisterForm from './components/RegisterForm';
import LoginForm from './components/LoginForm.jsx';


function App() {
  return (
    <div className="min-h-screen  flex items-center justify-center bg-gray-100">
      <LoginForm />
    </div>
  );
}

export default App;