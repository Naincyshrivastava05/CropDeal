import { useState } from 'react';
import FarmerSticker from '../assets/farmer.png'; // make sure this path matches your project

function RegisterForm() {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'USER',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Registering:', formData);
  };

  return (
    <div className=" flex justify-center relative w-full max-w-xl mx-auto mt-12">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-md p-6 bg-white/80 backdrop-blur-sm shadow-lg rounded-lg"
      >
        {['username', 'email', 'password', 'confirmPassword'].map((field) => (
          <div key={field} className="mb-4">
            <label
              htmlFor={field}
              className="block text-sm font-semibold text-gray-700 capitalize"
            >
              {field}
            </label>
            <input
              type={field.includes('password') ? 'password' : 'text'}
              name={field}
              id={field}
              value={formData[field]}
              onChange={handleChange}
              className="w-full px-4 py-2 mt-1 border rounded-md focus:outline-none focus:ring focus:ring-blue-300"
              required
            />
          </div>
        ))}

        <div className="mb-4">
          <label
            htmlFor="role"
            className="block text-sm font-semibold text-gray-700"
          >
            Role
          </label>
          <select
            name="role"
            id="role"
            value={formData.role}
            onChange={handleChange}
            className="w-full px-4 py-2 mt-1 border rounded-md focus:outline-none focus:ring focus:ring-blue-300"
            required
          >
            <option value="">-- Select a role --</option>
            <option value="FARMER">Farmer</option>
            <option value="DEALER">Dealer</option>
            <option value="ADMIN">Admin</option>
          </select>
        </div>

        <button
          type="submit"
          className="w-full bg-blue-500 text-white py-2 rounded-md hover:bg-blue-700 transition duration-200 mb-4"
        >
          Register
        </button>
          {/* 👨‍🌾 Sticker Below Button */}
  <div className="pointer-events-none absolute bottom-0 right-2 w-24 h-25 ">
    <img
      src={FarmerSticker}
      alt="Farmer sticker"
      className="w-20 h-20 "
    />
  </div>

      </form>

      {/* 🌾 Farmer Sticker
      <img
        src={FarmerSticker}
        alt="Farmer working"
        className="pointer-events-none absolute bottom-0 right-12 w-24 h-25 opacity-90"
      /> */}
    </div>
  );
}

export default RegisterForm;