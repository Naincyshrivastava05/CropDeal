import { useState } from 'react';
import FarmerSticker from '../assets/farmer.png';

function LoginForm() {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Logging in:', formData);
  };

  return (
    <div
      className="w-full min-h-screen bg-cover bg-center px-4 py-8 flex flex-col items-center"
      style={{ backgroundImage: "url('/images/bg-crop.jpg')" }}
    >
      {/* 🌾 Headline and Description OUTSIDE form */}
      <div className="text-center mb-6">
        <h1 className="text-4xl font-extrabold text-green-800 drop-shadow-md">
        Glad you're back—let’s grow together.
        </h1>
        <p className="text-sm text-gray-800 mt-2">
          Empowering farmers and dealers through a seamless digital marketplace.
        </p>
      </div>

      {/* Login Form Box */}
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-md p-6 bg-white/40 backdrop-blur-sm shadow-lg rounded-3xl "
      >
        <h2 className="text-2xl font-semibold text-center text-indigo-700 mb-6">
          Login
        </h2>

        <div className="mb-4">
          <label htmlFor="email" className="block text-sm font-medium text-gray-700">
            Email
          </label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className="w-full mt-1 px-4 py-2 border rounded-md focus:outline-none focus:ring focus:ring-indigo-300"
            required
          />
        </div>

        <div className="mb-6">
          <label htmlFor="password" className="block text-sm font-medium text-gray-700">
            Password
          </label>
          <input
            type="password"
            id="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            className="w-full mt-1 px-4 py-2 border rounded-md focus:outline-none focus:ring focus:ring-indigo-300"
            required
          />
        </div>

        <button
          type="submit"
          className="w-full bg-indigo-500 text-white py-2 rounded-md hover:bg-indigo-700 transition duration-200 mb-4"
        >
          Log In
        </button>

        {/* Sticker */}
        <div className="flex justify-center">
          <img
            src={FarmerSticker}
            alt="Farmer sticker"
            className="w-20 h-20 opacity-90"
          />
        </div>
      </form>
    </div>
  );
}

export default LoginForm;
